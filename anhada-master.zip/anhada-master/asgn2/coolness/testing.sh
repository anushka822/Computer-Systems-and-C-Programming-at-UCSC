./coolness

./coolness 32.0

./coolness 32.5 10 

./coolness 30 a 

./coolness 30 10 70 

./coolness b a 

./coolness 30 -100 

./coolness -1000 


