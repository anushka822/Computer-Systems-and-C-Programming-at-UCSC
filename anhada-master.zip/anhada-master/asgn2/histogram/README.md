Histogram, Anushka Hada,anhada@ucsc.edu

Description: Histogram takes in inputs. If inputs fall out if rage [0,16) double it. If it falls bettween bin sizes then add an asterick at the end.

File names and what they do:

.gitignore: Allows unwanted files to be not included

histogram.c: Actuall program

testing.out: Testing scripts output

testing.sh: Tests to check if histogram works as intented

Makefile: Compiles Histogram

README.md: Description of git repository and the files within		

How to compile: Once in the correct directory. Type in "make". This compiles the files.

How to run it: Type "./histogram". And then enter inputs. Once done press ctrl+D to end. 

