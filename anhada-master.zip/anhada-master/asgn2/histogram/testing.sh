echo 3 -4 5 1 7 0 8 0  3 -4 15 1 77 0 88 110 | ./histogram 
echo 0 0 1 1 2 2 88 99 100 | ./histogram 
echo 7 328 2 2 2000 92 1 0 0 0 0 | ./histogram 
echo 7 38 2  | ./histogram 
echo 1 2 3 | ./histogram 


