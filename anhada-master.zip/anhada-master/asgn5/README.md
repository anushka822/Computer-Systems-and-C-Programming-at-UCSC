Contains linked lists, sets, hashtables. 
Uses them all together for linked list. 
