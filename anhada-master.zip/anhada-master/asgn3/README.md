password_checker.c, Anushka Hada, anhada@ucsc.edu

